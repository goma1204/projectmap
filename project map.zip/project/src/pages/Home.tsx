import React from 'react';
import Header from '../components/UI/Header';
import Footer from '../components/UI/Footer';
import Map from '../components/Map/Map';
import JourneyPlanner from '../components/Journey/JourneyPlanner';
import JourneyHistory from '../components/Journey/JourneyHistory';
import { JourneyProvider } from '../contexts/JourneyContext';

const Home: React.FC = () => {
  return (
    <JourneyProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-1 bg-gray-100">
          <div className="container mx-auto py-6 px-4">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">Plan Your Journey</h1>
            
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3 space-y-4">
                <JourneyPlanner />
                <JourneyHistory />
              </div>
              
              <div className="md:w-2/3 h-[600px]">
                <Map />
              </div>
            </div>
            
            <div className="mt-10">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">How It Works</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <span className="text-blue-600 font-bold text-xl">1</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Select Points</h3>
                  <p className="text-gray-600">Click on the map to select your starting point and destination.</p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <span className="text-blue-600 font-bold text-xl">2</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Plan Route</h3>
                  <p className="text-gray-600">Review the route details including distance and estimated travel time.</p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <span className="text-blue-600 font-bold text-xl">3</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Start Journey</h3>
                  <p className="text-gray-600">Click start and watch as your car travels along the planned route.</p>
                </div>
              </div>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </JourneyProvider>
  );
};

export default Home;