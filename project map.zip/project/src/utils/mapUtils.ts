import { MapPoint, Route } from '../types';

export const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};

export const calculateDistance = (start: MapPoint, end: MapPoint): number => {
  const R = 6371;
  const dLat = toRad(end.lat - start.lat);
  const dLon = toRad(end.lng - start.lng);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(start.lat)) * Math.cos(toRad(end.lat)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10;
};

const toRad = (value: number): number => {
  return value * Math.PI / 180;
};

export const estimateDuration = (distance: number): number => {
  const avgSpeedKmh = 60;
  return Math.round((distance / avgSpeedKmh) * 60);
};

export const generateWaypoints = (
  start: MapPoint,
  end: MapPoint,
  arcFactor: number = 0.5,
  numPoints = 100
): [number, number][] => {
  const waypoints: [number, number][] = [];
  
  for (let i = 0; i <= numPoints; i++) {
    const t = i / numPoints;
    
    // Use cubic Bezier curve for smoother arc
    const p0 = [start.lat, start.lng];
    const p3 = [end.lat, end.lng];
    
    // Calculate control points for the Bezier curve
    const dx = end.lng - start.lng;
    const dy = end.lat - start.lat;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    // Perpendicular vector
    const perpX = -dy / dist;
    const perpY = dx / dist;
    
    // Control point offset (adjusted by arcFactor)
    const offset = dist * arcFactor;
    
    const p1 = [
      start.lat + (dy * 0.25) + (perpY * offset),
      start.lng + (dx * 0.25) + (perpX * offset)
    ];
    
    const p2 = [
      start.lat + (dy * 0.75) + (perpY * offset),
      start.lng + (dx * 0.75) + (perpX * offset)
    ];
    
    // Cubic Bezier interpolation
    const lat = Math.pow(1 - t, 3) * p0[0] +
                3 * Math.pow(1 - t, 2) * t * p1[0] +
                3 * (1 - t) * Math.pow(t, 2) * p2[0] +
                Math.pow(t, 3) * p3[0];
                
    const lng = Math.pow(1 - t, 3) * p0[1] +
                3 * Math.pow(1 - t, 2) * t * p1[1] +
                3 * (1 - t) * Math.pow(t, 2) * p2[1] +
                Math.pow(t, 3) * p3[1];
    
    waypoints.push([lat, lng]);
  }
  
  return waypoints;
};

export const calculateRoute = (start: MapPoint, end: MapPoint, arcFactor: number = 0.5): Route => {
  const distance = calculateDistance(start, end);
  const duration = estimateDuration(distance);
  const waypoints = generateWaypoints(start, end, arcFactor);
  
  return {
    id: generateId(),
    startPoint: start,
    endPoint: end,
    distance,
    duration,
    waypoints,
  };
};

export const getLocationName = (lat: number, lng: number): string => {
  return `Location (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
};

export const calculateHeading = (current: [number, number], next: [number, number]): number => {
  const dx = next[1] - current[1];
  const dy = next[0] - current[0];
  
  let angle = Math.atan2(dx, dy) * (180 / Math.PI);
  if (angle < 0) {
    angle += 360;
  }
  
  return angle;
};