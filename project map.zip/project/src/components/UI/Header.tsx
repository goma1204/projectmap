import React from 'react';
import { Car, Map as MapIcon, Globe } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm py-4 px-6">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Car size={24} className="text-blue-600" />
          <h1 className="text-xl font-bold text-gray-800">CarJourney</h1>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#" className="flex items-center text-gray-600 hover:text-blue-600 transition-colors">
            <MapIcon size={16} className="mr-1" />
            <span>Explore</span>
          </a>
          <a href="#" className="flex items-center text-gray-600 hover:text-blue-600 transition-colors">
            <Globe size={16} className="mr-1" />
            <span>Destinations</span>
          </a>
        </nav>
        
        <div className="flex items-center space-x-4">
          <button className="py-2 px-4 text-sm text-blue-600 hover:text-blue-700 transition-colors">
            Sign In
          </button>
          <button className="py-2 px-4 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            Get Started
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;