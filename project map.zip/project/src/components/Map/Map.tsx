import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, Polyline } from 'react-leaflet';
import { Icon, LatLngTuple } from 'leaflet';
import { Car, MapPin } from 'lucide-react';
import { useJourney } from '../../contexts/JourneyContext';
import { generateId, getLocationName } from '../../utils/mapUtils';
import 'leaflet/dist/leaflet.css';

import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const useMapClickHandler = () => {
  const { addPoint } = useJourney();
  const map = useMap();

  useEffect(() => {
    const handleMapClick = (e: any) => {
      const { lat, lng } = e.latlng;
      
      const newPoint = {
        id: generateId(),
        name: getLocationName(lat, lng),
        lat,
        lng,
        isSelected: true,
      };
      
      addPoint(newPoint);
    };

    map.on('click', handleMapClick);

    return () => {
      map.off('click', handleMapClick);
    };
  }, [map, addPoint]);

  return null;
};

const CarMarker: React.FC = () => {
  const { journeyState, updateCarPosition } = useJourney();
  const { carPosition, carProgress, isJourneyActive, currentRoute, speed } = journeyState;
  const map = useMap();

  useEffect(() => {
    if (!isJourneyActive || !currentRoute) return;

    const intervalId = setInterval(() => {
      updateCarPosition(carProgress + (0.1 * speed));
    }, 16); // 60 FPS update rate

    return () => clearInterval(intervalId);
  }, [isJourneyActive, carProgress, currentRoute, updateCarPosition, speed]);

  useEffect(() => {
    if (carPosition && isJourneyActive) {
      map.setView(carPosition as LatLngTuple, map.getZoom(), {
        animate: true,
        duration: 0.5
      });
    }
  }, [carPosition, isJourneyActive, map]);

  if (!carPosition) return null;

  const carIcon = new Icon({
    iconUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-icon.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  });

  return (
    <Marker 
      position={carPosition as LatLngTuple} 
      icon={carIcon}
      className="transition-all duration-500 ease-in-out"
    >
      <Popup>
        <div className="text-center">
          <p className="font-semibold">Current Position</p>
          <p className="text-sm text-gray-600">
            {carPosition[0].toFixed(4)}, {carPosition[1].toFixed(4)}
          </p>
          <p className="text-sm mt-1">
            Progress: {Math.round(carProgress)}%
          </p>
        </div>
      </Popup>
    </Marker>
  );
};

const RouteDisplay: React.FC = () => {
  const { journeyState } = useJourney();
  const { currentRoute, trail, isJourneyActive } = journeyState;

  if (!currentRoute) return null;

  return (
    <>
      <Polyline 
        positions={currentRoute.waypoints as LatLngTuple[]} 
        color="#1E3A8A" 
        weight={4} 
        opacity={0.7} 
        dashArray="10,10"
      />
      {isJourneyActive && trail.length > 0 && (
        <Polyline
          positions={trail as LatLngTuple[]}
          color="#4F46E5"
          weight={3}
          opacity={0.8}
          className="transition-all duration-500 ease-in-out"
        />
      )}
    </>
  );
};

const Map: React.FC = () => {
  const { journeyState } = useJourney();
  const { selectedPoints } = journeyState;
  const [defaultPosition] = useState<LatLngTuple>([20, 0]);
  const [defaultZoom] = useState(3);

  const customIcon = new Icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });

  useEffect(() => {
    const DefaultIcon = new Icon({
      iconUrl: icon,
      shadowUrl: iconShadow,
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
    });

    // @ts-ignore - known issue with Leaflet types
    L.Marker.prototype.options.icon = DefaultIcon;
  }, []);

  return (
    <div className="w-full h-full rounded-lg overflow-hidden shadow-lg">
      <MapContainer 
        center={defaultPosition} 
        zoom={defaultZoom} 
        style={{ height: '100%', width: '100%' }}
        zoomControl={false}
        attributionControl={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {selectedPoints.map((point) => (
          <Marker 
            key={point.id} 
            position={[point.lat, point.lng]} 
            icon={customIcon}
          >
            <Popup>
              <div className="text-center">
                <p className="font-semibold">{point.name}</p>
                <p className="text-sm text-gray-600">
                  {point.lat.toFixed(4)}, {point.lng.toFixed(4)}
                </p>
              </div>
            </Popup>
          </Marker>
        ))}
        
        <RouteDisplay />
        <CarMarker />
        <MapClickHandler />
      </MapContainer>
    </div>
  );
};

const MapClickHandler: React.FC = () => {
  useMapClickHandler();
  return null;
};

export default Map;