import React from 'react';
import { MapPin, Navigation, RotateCcw, Play, Clock, ArrowRight, FastForward, Move } from 'lucide-react';
import { useJourney } from '../../contexts/JourneyContext';

const JourneyPlanner: React.FC = () => {
  const { journeyState, startJourney, resetJourney, removePoint, setSpeed, setArcFactor } = useJourney();
  const { selectedPoints, currentRoute, isJourneyActive, carProgress, speed, arcFactor } = journeyState;

  const handleSpeedChange = (newSpeed: number) => {
    setSpeed(newSpeed);
  };

  const handleArcChange = (newArc: number) => {
    setArcFactor(newArc);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-full max-w-md">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Journey Planner</h2>
        <button
          onClick={resetJourney}
          className="p-2 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Reset journey"
        >
          <RotateCcw size={18} className="text-gray-600" />
        </button>
      </div>

      {selectedPoints.length === 0 ? (
        <div className="text-center py-8">
          <MapPin size={36} className="mx-auto text-blue-600 mb-2" />
          <p className="text-gray-600">Click on the map to select your starting point</p>
        </div>
      ) : selectedPoints.length === 1 ? (
        <div>
          <div className="flex items-center mb-3 p-3 bg-gray-50 rounded-lg">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
              <MapPin size={16} className="text-white" />
            </div>
            <div className="ml-3">
              <p className="font-medium">Start Point</p>
              <p className="text-sm text-gray-600">{selectedPoints[0].name}</p>
            </div>
            <button 
              onClick={() => removePoint(selectedPoints[0].id)}
              className="ml-auto p-1 rounded-full hover:bg-gray-200 transition-colors"
              aria-label="Remove point"
            >
              <RotateCcw size={14} className="text-gray-500" />
            </button>
          </div>
          <div className="text-center py-4">
            <p className="text-gray-600">Click on the map to select your destination</p>
          </div>
        </div>
      ) : (
        <div>
          <div className="flex items-center mb-3 p-3 bg-gray-50 rounded-lg">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
              <MapPin size={16} className="text-white" />
            </div>
            <div className="ml-3">
              <p className="font-medium">Start Point</p>
              <p className="text-sm text-gray-600">{selectedPoints[0].name}</p>
            </div>
            <button 
              onClick={() => removePoint(selectedPoints[0].id)}
              className="ml-auto p-1 rounded-full hover:bg-gray-200 transition-colors"
              aria-label="Remove point"
            >
              <RotateCcw size={14} className="text-gray-500" />
            </button>
          </div>
          
          <div className="flex justify-center my-2">
            <ArrowRight size={18} className="text-gray-400" />
          </div>
          
          <div className="flex items-center mb-4 p-3 bg-gray-50 rounded-lg">
            <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0">
              <Navigation size={16} className="text-white" />
            </div>
            <div className="ml-3">
              <p className="font-medium">Destination</p>
              <p className="text-sm text-gray-600">{selectedPoints[1].name}</p>
            </div>
            <button 
              onClick={() => removePoint(selectedPoints[1].id)}
              className="ml-auto p-1 rounded-full hover:bg-gray-200 transition-colors"
              aria-label="Remove point"
            >
              <RotateCcw size={14} className="text-gray-500" />
            </button>
          </div>

          <div className="mb-4 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center mb-4">
              <Move size={16} className="text-blue-700 mr-2" />
              <span className="text-sm font-medium">Route Arc</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={arcFactor}
                onChange={(e) => handleArcChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer ml-4"
              />
            </div>
            
            <div className="flex justify-between mb-2">
              <div className="flex items-center">
                <Navigation size={16} className="text-blue-700 mr-2" />
                <span className="text-sm font-medium">Distance</span>
              </div>
              <span className="text-sm font-semibold">{currentRoute?.distance} km</span>
            </div>
            
            <div className="flex justify-between">
              <div className="flex items-center">
                <Clock size={16} className="text-blue-700 mr-2" />
                <span className="text-sm font-medium">Est. Time</span>
              </div>
              <span className="text-sm font-semibold">
                {currentRoute?.duration && (
                  currentRoute.duration < 60 
                    ? `${currentRoute.duration} min` 
                    : `${Math.floor(currentRoute.duration / 60)} hr ${currentRoute.duration % 60} min`
                )}
              </span>
            </div>
          </div>
          
          {isJourneyActive ? (
            <div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
                <div 
                  className="bg-blue-600 h-2.5 rounded-full transition-all duration-300 ease-in-out" 
                  style={{ width: `${carProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-center text-gray-600 mb-4">
                {carProgress < 100 
                  ? `Journey in progress: ${Math.round(carProgress)}%` 
                  : 'Journey completed!'}
              </p>
              <div className="flex items-center justify-center space-x-4">
                <FastForward size={16} className="text-gray-600" />
                <input
                  type="range"
                  min="0.5"
                  max="5"
                  step="0.5"
                  value={speed}
                  onChange={(e) => handleSpeedChange(parseFloat(e.target.value))}
                  className="w-32 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm text-gray-600">{speed}x</span>
              </div>
            </div>
          ) : (
            <button
              onClick={startJourney}
              disabled={!currentRoute}
              className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <Play size={18} className="mr-2" />
              Start Journey
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default JourneyPlanner;