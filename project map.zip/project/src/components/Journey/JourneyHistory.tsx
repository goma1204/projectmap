import React from 'react';
import { History, Navigation, Clock, ChevronRight } from 'lucide-react';
import { useJourney } from '../../contexts/JourneyContext';

const JourneyHistory: React.FC = () => {
  const { journeyState, selectJourneyFromHistory } = useJourney();
  const { journeyHistory } = journeyState;

  if (journeyHistory.length === 0) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-full max-w-md mt-4">
      <div className="flex items-center mb-4">
        <History size={18} className="text-blue-600 mr-2" />
        <h2 className="text-lg font-semibold text-gray-800">Journey History</h2>
      </div>

      <div className="space-y-3 max-h-60 overflow-y-auto">
        {journeyHistory.map((route) => (
          <button
            key={route.id}
            onClick={() => selectJourneyFromHistory(route.id)}
            className="w-full text-left p-3 rounded-lg hover:bg-gray-50 transition-colors flex items-center"
          >
            <div className="flex-1">
              <div className="flex items-center">
                <span className="font-medium text-gray-800">{route.startPoint.name}</span>
                <ChevronRight size={16} className="mx-1 text-gray-400" />
                <span className="font-medium text-gray-800">{route.endPoint.name}</span>
              </div>
              
              <div className="flex mt-1 text-sm text-gray-600">
                <div className="flex items-center mr-3">
                  <Navigation size={14} className="mr-1" />
                  <span>{route.distance} km</span>
                </div>
                <div className="flex items-center">
                  <Clock size={14} className="mr-1" />
                  <span>
                    {route.duration < 60 
                      ? `${route.duration} min` 
                      : `${Math.floor(route.duration / 60)} hr ${route.duration % 60} min`}
                  </span>
                </div>
              </div>
            </div>
            
            <ChevronRight size={18} className="text-gray-400" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default JourneyHistory;