import React, { createContext, useContext, useState } from 'react';
import { JourneyState, MapPoint, Route } from '../types';
import { calculateRoute } from '../utils/mapUtils';

interface JourneyContextType {
  journeyState: JourneyState;
  addPoint: (point: MapPoint) => void;
  removePoint: (pointId: string) => void;
  startJourney: () => void;
  resetJourney: () => void;
  updateCarPosition: (progress: number) => void;
  selectJourneyFromHistory: (routeId: string) => void;
  setSpeed: (speed: number) => void;
  setArcFactor: (factor: number) => void;
}

const initialState: JourneyState = {
  selectedPoints: [],
  currentRoute: null,
  journeyHistory: [],
  carPosition: null,
  carProgress: 0,
  isJourneyActive: false,
  speed: 1,
  arcFactor: 0.5,
  trail: [],
};

const JourneyContext = createContext<JourneyContextType | undefined>(undefined);

export const JourneyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [journeyState, setJourneyState] = useState<JourneyState>(initialState);

  const addPoint = (point: MapPoint) => {
    setJourneyState(prev => {
      const updatedPoints = prev.selectedPoints.length < 2 
        ? [...prev.selectedPoints, point]
        : [prev.selectedPoints[0], point];
      
      const newRoute = updatedPoints.length === 2 
        ? calculateRoute(updatedPoints[0], updatedPoints[1], prev.arcFactor) 
        : null;

      return {
        ...prev,
        selectedPoints: updatedPoints,
        currentRoute: newRoute,
      };
    });
  };

  const removePoint = (pointId: string) => {
    setJourneyState(prev => ({
      ...prev,
      selectedPoints: prev.selectedPoints.filter(p => p.id !== pointId),
      currentRoute: null,
      carPosition: null,
      carProgress: 0,
      isJourneyActive: false,
      trail: [],
    }));
  };

  const startJourney = () => {
    if (journeyState.selectedPoints.length !== 2 || !journeyState.currentRoute) return;
    
    setJourneyState(prev => {
      const routeExists = prev.journeyHistory.some(r => r.id === prev.currentRoute?.id);
      const updatedHistory = routeExists 
        ? prev.journeyHistory 
        : [...prev.journeyHistory, prev.currentRoute!];
      
      return {
        ...prev,
        journeyHistory: updatedHistory,
        carPosition: [prev.currentRoute!.startPoint.lat, prev.currentRoute!.startPoint.lng],
        carProgress: 0,
        isJourneyActive: true,
        trail: [[prev.currentRoute!.startPoint.lat, prev.currentRoute!.startPoint.lng]],
      };
    });
  };

  const resetJourney = () => {
    setJourneyState(prev => ({
      ...prev,
      selectedPoints: [],
      currentRoute: null,
      carPosition: null,
      carProgress: 0,
      isJourneyActive: false,
      trail: [],
    }));
  };

  const updateCarPosition = (progress: number) => {
    if (!journeyState.currentRoute || !journeyState.isJourneyActive) return;
    
    const { waypoints } = journeyState.currentRoute;
    if (waypoints.length < 2) return;
    
    const clampedProgress = Math.min(Math.max(progress, 0), 100);
    const waypointIndex = Math.floor((waypoints.length - 1) * (clampedProgress / 100));
    
    const currentWaypoint = waypoints[waypointIndex];
    const nextWaypoint = waypoints[Math.min(waypointIndex + 1, waypoints.length - 1)];
    
    const segmentProgress = (clampedProgress % (100 / (waypoints.length - 1))) / (100 / (waypoints.length - 1));
    
    const lat = currentWaypoint[0] + (nextWaypoint[0] - currentWaypoint[0]) * segmentProgress;
    const lng = currentWaypoint[1] + (nextWaypoint[1] - currentWaypoint[1]) * segmentProgress;
    
    const newPosition: [number, number] = [lat, lng];
    
    setJourneyState(prev => ({
      ...prev,
      carPosition: newPosition,
      carProgress: clampedProgress,
      isJourneyActive: clampedProgress < 100,
      trail: [...prev.trail, newPosition],
    }));
  };

  const selectJourneyFromHistory = (routeId: string) => {
    const route = journeyState.journeyHistory.find(r => r.id === routeId);
    if (!route) return;
    
    setJourneyState(prev => ({
      ...prev,
      selectedPoints: [route.startPoint, route.endPoint],
      currentRoute: route,
      carPosition: null,
      carProgress: 0,
      isJourneyActive: false,
      trail: [],
    }));
  };

  const setSpeed = (speed: number) => {
    setJourneyState(prev => ({
      ...prev,
      speed,
    }));
  };

  const setArcFactor = (factor: number) => {
    setJourneyState(prev => {
      const newRoute = prev.selectedPoints.length === 2
        ? calculateRoute(prev.selectedPoints[0], prev.selectedPoints[1], factor)
        : prev.currentRoute;

      return {
        ...prev,
        arcFactor: factor,
        currentRoute: newRoute,
      };
    });
  };

  return (
    <JourneyContext.Provider 
      value={{ 
        journeyState, 
        addPoint, 
        removePoint, 
        startJourney, 
        resetJourney, 
        updateCarPosition, 
        selectJourneyFromHistory,
        setSpeed,
        setArcFactor
      }}
    >
      {children}
    </JourneyContext.Provider>
  );
};

export const useJourney = () => {
  const context = useContext(JourneyContext);
  if (context === undefined) {
    throw new Error('useJourney must be used within a JourneyProvider');
  }
  return context;
};