export interface MapPoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  isSelected: boolean;
}

export interface Route {
  id: string;
  startPoint: MapPoint;
  endPoint: MapPoint;
  distance: number; // in kilometers
  duration: number; // in minutes
  waypoints: [number, number][]; // array of [lat, lng] coordinates
}

export interface JourneyState {
  selectedPoints: MapPoint[];
  currentRoute: Route | null;
  journeyHistory: Route[];
  carPosition: [number, number] | null;
  carProgress: number; // 0-100%
  isJourneyActive: boolean;
  speed: number; // Speed multiplier (1 = normal speed)
  arcFactor: number; // Arc factor for route curvature (0-1)
  trail: [number, number][]; // Trail of positions the car has traveled
}